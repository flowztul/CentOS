#include "capabilities.h"

#define FAKEDEVDIR0 "/fakedevdir0/bla/fasl"
#define FAKEDEVDIR1 "/fakedevdir1/bla/fasl"

virCapsPtr testLXCCapsInit(void);
